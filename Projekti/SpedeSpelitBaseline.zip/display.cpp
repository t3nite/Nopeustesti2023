#include "display.h"


void initializeDisplay(void)
{
// See requirements for this function from display.h
}


void writeByte(uint8_t bits,bool last)
{
// See requirements for this function from display.h
}


void writeHighAndLowNumber(uint8_t tens,uint8_t ones)
{
// See requirements for this function from display.h
}

void showResult(byte number)
{
// See requirements for this function from display.h
}

