#include "leds.h"


void initializeLeds()
{
// see requirements for this function from leds.h
}

void setLed(byte ledNumber)
{
// see requirements for this function from leds.h

}


void clearAllLeds()
{
// see requirements for this function from leds.h
 
}

void setAllLeds()
{
// see requirements for this function from leds.h
}
